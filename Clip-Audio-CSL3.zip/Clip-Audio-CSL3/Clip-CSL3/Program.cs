﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace Clip_Audio_CSL3
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            List<string> participantsEntriesList = new List<string>();
            CSVHandler.CSVHandler csvParticipants = new CSVHandler.CSVHandler(Constants.PARTICIPANTS_LIST);
            while (!csvParticipants.endOfData())
                participantsEntriesList.Add(csvParticipants.getNextRow()["Participants_Entry"]);

            EnterParticipants entries = new EnterParticipants();
            string[] participants = null;

            bool fileGenerated = true;
            while (fileGenerated)
            {
                participants = entries.ShowDialog(participantsEntriesList).Split(' ');
                if (Constants.PARTICIPANT == 0)
                    fileGenerated = entries.fileGenerated(participants[1] + "-audio-clipped.wav", participants[0]);
                else if (Constants.PARTICIPANT == 1)
                    fileGenerated = entries.fileGenerated(participants[2] + "-audio-clipped.wav", participants[0]);
                else if (Constants.PARTICIPANT == 2)
                    fileGenerated = entries.fileGenerated(participants[3] + "-audio-clipped.wav", participants[0]);
                else
                    fileGenerated = entries.fileGenerated(participants[0] + "-zoom_audio_0-clipped.wav", participants[0]);

                if (fileGenerated)
                {
                    MessageBox.Show("This participant already has a clipped video. Please select another.");
                }

            }

            string teamNum = participants[0];
            string subjectIDA = participants[1];
            string subjectIDB = participants[2];
            string subjectIDC = participants[3];
            string participant = null;

            switch (Constants.PARTICIPANT)
            {
                case 0:
                    participant = subjectIDA;
                    break;
                case 1:
                    participant = subjectIDB;
                    break;
                case 2:
                    participant = subjectIDC;
                    break;
                case 3:
                    participant = "Zoom";
                    break;
            }

            ClipAudio clipParticipant;

            if (Constants.PARTICIPANT == 3)
            {
                clipParticipant = new ClipAudio(
                    Constants.INTERACTION_DIRECTORY + "\\CSL3-" + teamNum + "-interaction.txt",
                    Constants.RATING_POSITIONS_DIRECTORY + teamNum + "\\CSL3-" + teamNum + "-master-rating-positions.txt",
                    Constants.CUT_LOG_DIRECTORY + teamNum + "-" + participant + "-cut-log.txt",
                    teamNum, subjectIDA, subjectIDB, subjectIDC, participant);
                clipParticipant.getZoomStartStopTime();
                clipParticipant.performClip();
            }

            else
            {
                clipParticipant = new ClipAudio(
                    Constants.FRAMELOG_DIRECTORY + "\\" + teamNum + "\\" + participant + "-Challenges-framelog.txt",
                    Constants.RATING_POSITIONS_DIRECTORY + teamNum + "\\CSL3-" + teamNum + "-master-rating-positions.txt",
                    Constants.CUT_LOG_DIRECTORY + participant + "-cut-log.txt",
                    teamNum, subjectIDA, subjectIDB, subjectIDC, participant);
                clipParticipant.getStartStopTime();
                clipParticipant.performClip();
            }

            

            

        }
    }
}